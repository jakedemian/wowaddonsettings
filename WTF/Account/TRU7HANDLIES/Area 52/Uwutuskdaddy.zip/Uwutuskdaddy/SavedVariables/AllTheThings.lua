
AllTheThingsSettingsPerCharacter = {
	["Filters"] = {
	},
}
