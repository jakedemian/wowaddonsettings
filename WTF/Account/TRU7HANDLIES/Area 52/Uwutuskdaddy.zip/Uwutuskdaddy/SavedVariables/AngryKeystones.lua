
AngryKeystones_CharacterConfig = {
	["__version"] = 1,
}
