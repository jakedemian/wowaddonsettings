
_detalhes_databaseRaidPowerBar = nil
